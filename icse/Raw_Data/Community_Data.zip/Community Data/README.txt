The provided data is in the form of an R object. For information on how to install the R programming environment consult http://www.r-project.org/

To load the data, inside an R terminal enter:
load("community_data.dat")

A data frame will be then be loaded into the workspace. The data frame contains statistical information on all subject projects community structure including:
- name of project
- revision range of analysis
- analysis method used (file=file-based, proximity=function-based)
- number of developers participation to the release
- number of communities
- mean community size
- standard deviation community size
- conductance for each community
- randomized network conductance 
- modularity
- mean number of edges in communities
- standard deviation number of edges in communities